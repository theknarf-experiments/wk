# Inside a zip

This file lives inside example/demo-archive.zip.
The zipfs node decompresses it on demand — the archive was
never unpacked anywhere.
